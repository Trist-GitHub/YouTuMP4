# HTML5 video player
---------------------
A video player made fully in html.

You dont need to download it, since its on the web. We are thinking of making an app version soon.

Make sure you have <code>HTML5</code> on your device here: https://html5test.com/. 
click the link and look at the <code>video</code> and <code>audio</code> sections to check if the video and audio elements are available on your device.
